
import React, { useState, useEffect, useMemo } from 'react';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import ProductCard from './components/ProductCard';
import { DRESSITOS_PRODUCTS, FALLASTYLE_PRODUCTS, ARREGLOS_SERVICES, TESTIMONIALS } from './constants';
import { getArtisanAdvice } from './services/geminiService';
import { Product } from './types';

interface ProductGalleryProps {
  title: string;
  products: Product[];
  heroData: { subtitle: string; img: string };
  showTraditionSection?: boolean;
}

const ProductGallery: React.FC<ProductGalleryProps> = ({ title, products, heroData, showTraditionSection }) => {
  const [selectedCat, setSelectedCat] = useState('Todos');
  
  const categories = useMemo(() => {
    return ['Todos', ...Array.from(new Set(products.map(p => p.category)))];
  }, [products]);

  const filtered = selectedCat === 'Todos' 
    ? products 
    : products.filter(p => p.category === selectedCat);

  return (
    <div className="min-h-screen bg-background-light dark:bg-background-dark pb-40">
      {/* Header Hero */}
      <div className="relative h-[500px] w-full flex items-center justify-center overflow-hidden mb-20">
        <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `linear-gradient(rgba(0,0,0,0.4), rgba(0,0,0,0.6)), url("${heroData.img}")` }} />
        <div className="relative z-10 text-center px-6 max-w-4xl animate-reveal">
          <span className="inline-block px-4 py-1 mb-6 text-xs font-bold uppercase tracking-[0.3em] text-white bg-primary/80 rounded-full backdrop-blur-md">Nueva Colección 2024</span>
          <h1 className="text-5xl md:text-7xl font-display font-black text-white mb-6 drop-shadow-2xl">{title}</h1>
          <p className="text-lg md:text-xl text-white/90 font-medium max-w-2xl mx-auto drop-shadow-md">
            {heroData.subtitle}
          </p>
        </div>
      </div>

      <div className="max-w-[1400px] mx-auto px-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-8 mb-16 border-b border-primary/10 pb-8">
          <h2 className="text-2xl font-bold font-display text-text-main dark:text-white">Explorar Productos</h2>
          <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
            {categories.map(cat => (
              <button 
                key={cat}
                onClick={() => setSelectedCat(cat)}
                className={`px-8 py-3 rounded-full text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${
                  selectedCat === cat 
                    ? 'bg-primary text-white shadow-lg' 
                    : 'bg-white dark:bg-white/10 text-text-secondary dark:text-gray-300 border border-primary/10 hover:border-primary'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-x-8 gap-y-20 animate-reveal">
          {filtered.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>

        {showTraditionSection && (
          <section className="mt-40 py-24 bg-white dark:bg-[#2a1f17] rounded-[4rem] border border-primary/5 shadow-inner">
             <div className="max-w-[800px] mx-auto px-6 text-center">
                <div className="inline-flex items-center justify-center size-20 rounded-full bg-primary/10 text-primary mb-8">
                  <span className="material-symbols-outlined !text-4xl">history_edu</span>
                </div>
                <h3 className="text-4xl font-display font-bold mb-8">El Arte de la Tradición</h3>
                <p className="text-lg text-text-secondary dark:text-gray-300 leading-relaxed mb-12">
                  Nuestra colección "Fallastyle" nace del amor por la indumentaria valenciana. Cada pieza está confeccionada artesanalmente utilizando retales de sedas, damascos y brocateles que cuentan historias de nuestra fiesta.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-12 text-center border-t border-primary/10 pt-12">
                  {[
                    { icon: 'pan_tool', title: 'Hecho a Mano', desc: 'Artesanía en Valencia' },
                    { icon: 'recycling', title: 'Sostenible', desc: 'Tejidos nobles' },
                    { icon: 'diamond', title: 'Exclusivo', desc: 'Series limitadas' }
                  ].map((item, idx) => (
                    <div key={idx} className="flex flex-col items-center gap-2">
                      <span className="material-symbols-outlined !text-4xl text-primary">{item.icon}</span>
                      <h4 className="font-bold text-sm uppercase tracking-widest">{item.title}</h4>
                      <p className="text-[10px] text-text-secondary uppercase tracking-widest">{item.desc}</p>
                    </div>
                  ))}
                </div>
             </div>
          </section>
        )}

        {filtered.length === 0 && (
          <div className="py-40 text-center">
            <span className="material-symbols-outlined !text-6xl text-primary/20 mb-4">inventory_2</span>
            <p className="text-xl font-bold text-text-secondary">Próximamente nuevas creaciones...</p>
            <button onClick={() => setSelectedCat('Todos')} className="mt-6 text-primary font-bold border-b border-primary pb-1">Ver todos los productos</button>
          </div>
        )}
      </div>
    </div>
  );
};

const ConceptBlockA: React.FC<{ 
  title: string; 
  description: string; 
  img: string; 
  reverse?: boolean; 
  delay?: string 
}> = ({ title, description, img, reverse, delay = "0ms" }) => (
  <div className={`flex flex-col ${reverse ? 'md:flex-row-reverse' : 'md:flex-row'} items-center gap-12 lg:gap-24 mb-32 animate-reveal`} style={{ animationDelay: delay }}>
    <div className="w-full md:w-1/2 overflow-hidden rounded-[3rem] shadow-2xl aspect-[4/3]">
      <img src={img} alt={title} className="w-full h-full object-cover hover:scale-105 transition-transform duration-[2s]" />
    </div>
    <div className="w-full md:w-1/2 flex flex-col justify-center">
      <h3 className="text-display font-black uppercase tracking-[0.4em] text-[2rem] mb-4">{title}</h3>
      <p className="text-2xl lg:text-3xl font-display font-medium text-text-main dark:text-white leading-snug">
        {description}
      </p>
    </div>
  </div>
);

const ConceptBlockB: React.FC<{ 
  title: string; 
  description: string; 
  img: string; 
  reverse?: boolean; 
  delay?: string 
}> = ({ title, description, img, reverse, delay = "0ms" }) => (
  <div className={`flex flex-col ${reverse ? 'md:flex-row-reverse' : 'md:flex-row'} items-center gap-12 lg:gap-24 mb-32 animate-reveal`} style={{ animationDelay: delay }}>
    <div className="w-full md:w-1/2 overflow-hidden rounded-[3rem] shadow-2xl aspect-[4/3]">
      <img src={img} alt={title} className="w-full h-full object-cover hover:scale-105 transition-transform duration-[2s]" />
    </div>
    <div className="w-full md:w-1/2 flex flex-col justify-center">
      <h3 className="text-primary font-black uppercase tracking-[0.4em] text-[2rem] mb-4">{title}</h3>
      <p className="text-2xl lg:text-3xl font-display font-medium text-text-main dark:text-white leading-snug">
        {description}
      </p>
    </div>
  </div>
);

const BespokeStep: React.FC<{ number: string, title: string, desc: string, icon: string }> = ({ number, title, desc, icon }) => (
  <div className="relative p-10 bg-white dark:bg-white/5 rounded-[3rem] border border-primary/10 shadow-xl group hover:-translate-y-2 transition-transform duration-500">
    <div className="absolute -top-6 -right-6 size-16 rounded-3xl bg-primary text-white flex items-center justify-center font-display font-bold text-2xl shadow-xl z-10">{number}</div>
    <div className="size-16 rounded-2xl bg-primary/10 text-primary flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
      <span className="material-symbols-outlined !text-3xl">{icon}</span>
    </div>
    <h4 className="text-xl font-bold font-display mb-4">{title}</h4>
    <p className="text-sm text-text-secondary dark:text-gray-400 leading-relaxed italic">"{desc}"</p>
  </div>
);

const Home: React.FC<{ onNavigate: (tab: string) => void }> = ({ onNavigate }) => (
  <div className="flex flex-col gap-0 pb-0 overflow-hidden">
    <section className="relative min-h-[60vh] lg:min-h-[80vh] w-full flex items-center justify-center overflow-hidden py-32">
      <div className="absolute inset-0 z-0">
         <img 
          src="https://lh3.googleusercontent.com/aida-public/AB6AXuD3Ftyi010TvuODent0xLMAOEWD9JkkqB2z2qMki9gxMCQ-ZioFijrKx8QqIwJ98EI2MSi0DnLp3Ea5d-o6e_kqymrgNycQ1GQ1_mJJZ2em3ql_vBCRLmITL5fUgYUcAOnrLjbg2BiIbDFSCB_0aobz4zPT9ewNXl3IyURKcyZ7cWGryiKFgiCcj2JpgVgKFCPvMzAcUYET9D9EEBddVHv9NsmIvRzY02XEFHa8gDi9iXl0u-NNh-DtIQXll-W9BzH9iYR2q38MhkEG" 
          className="w-full h-full object-cover opacity-50 dark:opacity-30 transition-opacity duration-1000 blur-[2px] scale-105"
          alt="Creativa Textil Hero"
         />
      </div>
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-background-light/40 to-background-light dark:via-background-dark/60 dark:to-background-dark z-[1]" />
      <div className="relative z-10 flex flex-col items-center text-center px-6 max-w-[1200px]">
        <span className="text-[10px] font-black uppercase tracking-[0.5em] text-primary mb-6 animate-reveal">Desde 2012 · Valencia</span>
        <h1 className="text-5xl sm:text-7xl lg:text-[7rem] font-display font-black leading-none mb-24 animate-reveal [animation-delay:200ms] drop-shadow-xl text-display">
          Creativa Textil <br/> <span className="text-primary italic font-light">Artesanal</span>
        </h1>
        <p className="text-lg sm:text-2xl text-text-main dark:text-gray-300 font-serif italic max-w-8xl animate-reveal [animation-delay:400ms] mb-10">
          Así nace un universo textil artesanal donde cada pieza se reconoce por su esencia
        </p>

        {/* Concept Blocks Section */}
        <div className="w-full text-left mt-10">
          <ConceptBlockA 
            title="CREATIVA" 
            description="Porque de una pequeña idea surgen múltiples versiones que confluyen en algo original y exclusivo."
            img="https://images.unsplash.com/photo-1520032484190-e5ef81d87978?q=80&w=2070&auto=format&fit=crop"
            delay="400ms"
          />
          <ConceptBlockA 
            title="TEXTIL" 
            description="Multitud de fibras desde las más naturales hasta las más sofisticadas, se entrelazan formando auténticas obras de arte."
            img="https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?q=80&w=2072&auto=format&fit=crop"
            reverse
            delay="600ms"
          />
          <ConceptBlockB 
            title="ARTESANAL" 
            description="Por su elaboración así definida y a escala doméstica , imprime un sello único y personal."
            img="https://images.unsplash.com/photo-1517673132405-a56a62b18caf?q=80&w=2076&auto=format&fit=crop"
            delay="800ms"
          />
        </div>
      </div>
    </section>

    <section className="py-32 px-6 bg-white dark:bg-background-dark">
      <div className="max-w-[1200px] mx-auto text-center mb-20">
        <span className="text-primary font-bold uppercase tracking-[0.3em] text-xs mb-4 block">Nuestras Especialidades</span>
        <h2 className="text-[2rem] font-display font-serif italic mb-4">"Cada puntada cuenta una historia, cada tejido guarda un recuerdo"</h2>
        <div className="w-20 h-1 bg-primary mx-auto rounded-full" />
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-12">
        {[
          { id: 'dressitos', title: 'Dressitos', desc: 'Moda Infantil Hecha a Mano', img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuD__u_D8F3yNDJL57dK7n0kdoOf3Nf4FuhtxdoFvdSzgW9wGfA3jT8jG6xxjjaBPvQ2TMKAeU6V60YdrLP8ZPekr8ek_UlNrKAQ8ZZ0oCpeABfGWNOyn4YwAS6pPNPds7Fq8u-e8lbDj__XLIazr3rAG_SnsutBsUDGmf_MnAjhr2yfg9r7v3atS-z5YytfDUK3piQAk5iiAH5yPhr53XZzMhM8PJBayDQpD-uqcquoAj_kp9pTUwfMT_gnPSRlK0eDETsJFM90XFad' },
          { id: 'fallastyle', title: 'Fallastyle', desc: 'Tradición Valenciana Única', img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuA-AOX3J5jt501XOyxf9J1SJLcCGFxIxVzcdpei7PXT9lehmW9UBfHGCvjlpMFEX2Nkmk1aVNEptvbk5o6N2oq5W8HkoCcVFrwwE_eG38eC4r7KcN3IGRfaUzgQ2hcuTnC72JAVLiUg22aTk08kSllenkn_7nbEGuhfpGISttlpkPzwzyKo1wHIXVRJlTRBfy1OuWAnkwnXOfhGeswcUjDlK-OuQpZfGB6YLzWkcaJfWME-xAjz1kUWnJqcSGb03MRPC2e6kYzHkiMW' },
          { id: 'arreglos', title: 'Arreglos', desc: 'Segunda Vida a tus Prendas', img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuC8vuiH1TN1K0sX5-lf7kw131pSGB4z57OLY4HS1BQyQHotTfNyWloTrdPKl41bHSm40-Y7YjXIKejRL4LkyTsypwXfVrtC_6Xjd6HsVaBzcFLBX43BSU5WB57QywsHNr86lQgN_5-a3K_4ESdmb5QYzOBkDHVj5L8dIxv_mpNEpexY34euBfeWCgXYAlg4j_WflwSYcPROSSouizXjX0m2R4uaTn7lmnthob-CTz9B71Yz-81-J5v4lB-S7AEfIAzydcioK9syI8rS' },
          { id: 'a-tu-medida', title: 'A tu medida', desc: 'Confección Exclusiva', img: 'https://images.unsplash.com/photo-1558487661-9d4f01e2ad64?q=80&w=2070&auto=format&fit=crop' }
        ].map((item) => (
          <div key={item.id} className="group relative h-[450px] overflow-hidden rounded-[3rem] cursor-pointer shadow-xl transition-all hover:shadow-2xl" onClick={() => onNavigate(item.id)}>
            <img src={item.img} className="w-full h-full object-cover transition-transform duration-[2s] group-hover:scale-110" alt={item.title} />
            <div className="absolute inset-0 bg-gradient-to-t from-background-dark/90 via-transparent to-transparent opacity-80" />
            <div className="absolute bottom-10 left-10 right-10 text-white">
              <p className="text-primary font-bold text-[10px] uppercase tracking-widest mb-1">{item.desc}</p>
              <h3 className="text-2xl font-display font-bold">{item.title}</h3>
              <div className="mt-4 flex items-center gap-2 text-sm font-bold opacity-0 group-hover:opacity-100 transition-opacity duration-500">Explorar <span className="material-symbols-outlined !text-[18px]">arrow_forward</span></div>
            </div>
          </div>
        ))}
      </div>
    </section>
  </div>
);

const App: React.FC = () => {
  const [currentTab, setCurrentTab] = useState('inicio');
  const [isAiOpen, setIsAiOpen] = useState(false);
  const [aiMessage, setAiMessage] = useState('');
  const [aiInput, setAiInput] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);
  const ENABLE_AI_ASSISTANT = false;

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentTab]);

  const handleAiConsult = async () => {
    if (!aiInput.trim()) return;
    setIsAiLoading(true);
    const result = await getArtisanAdvice(aiInput);
    setAiMessage(result || '');
    setIsAiLoading(false);
    setAiInput('');
  };

  const renderContent = () => {
    switch (currentTab) {
      case 'inicio':
        return <Home onNavigate={setCurrentTab} />;
      case 'a-tu-medida':
        return (
          <div className="min-h-screen bg-background-light dark:bg-background-dark pb-40">
            {/* Header Hero */}
            <div className="relative h-[600px] w-full flex items-center justify-center overflow-hidden mb-32">
              <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: 'linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.7)), url("https://images.unsplash.com/photo-1558487661-9d4f01e2ad64?q=80&w=2070&auto=format&fit=crop")' }} />
              <div className="relative z-10 text-center px-6 max-w-4xl animate-reveal">
                <span className="inline-block px-4 py-1 mb-6 text-[10px] font-black uppercase tracking-[0.4em] text-white bg-primary/80 rounded-full backdrop-blur-md shadow-2xl">Exclusividad & Elegancia</span>
                <h1 className="text-6xl md:text-8xl font-display font-black text-white mb-8 drop-shadow-2xl">A tu Medida</h1>
                <p className="text-xl md:text-2xl text-white/90 font-serif italic max-w-3xl mx-auto drop-shadow-md leading-relaxed">
                  "Creamos la prenda de tus sueños desde cero. Un proceso íntimo, pausado y totalmente personalizado en nuestro taller de Valencia."
                </p>
                <div className="mt-12 flex justify-center gap-6">
                  <button onClick={() => setCurrentTab('contacto')} className="bg-white text-primary px-10 py-5 rounded-full font-black uppercase tracking-widest text-xs shadow-2xl hover:bg-primary hover:text-white transition-all">Pedir Cita Previa</button>
                  <button className="bg-transparent border-2 border-white/30 text-white px-10 py-5 rounded-full font-black uppercase tracking-widest text-xs backdrop-blur-sm hover:border-white transition-all">Ver Galería</button>
                </div>
              </div>
            </div>

            <div className="max-w-[1400px] mx-auto px-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-24 items-center mb-40">
                <div className="relative">
                  <div className="aspect-[4/5] rounded-[4rem] overflow-hidden shadow-2xl relative z-10">
                    <img src="https://images.unsplash.com/photo-1594938298603-c8148c4dae35?q=80&w=1780&auto=format&fit=crop" className="w-full h-full object-cover" alt="Measuring" />
                  </div>
                  <div className="absolute -bottom-12 -right-12 size-64 bg-primary/10 rounded-[4rem] -z-0 blur-3xl" />
                </div>
                <div>
                   <span className="text-primary font-black uppercase tracking-[0.4em] text-[10px] mb-6 block">El Proceso Artesano</span>
                   <h2 className="text-5xl font-display font-bold mb-10 leading-tight text-text-main dark:text-white">Una experiencia diseñada <br/> solo para ti</h2>
                   <p className="text-lg text-text-secondary dark:text-gray-300 mb-12 leading-relaxed">
                     Entendemos la moda como una extensión de tu personalidad. En el servicio "A tu medida", no hay límites. Desde la elección inicial de la seda valenciana o el lino más puro, hasta el último ajuste en la sisa, cada detalle se supervisa personalmente por Elvira.
                   </p>
                   <ul className="space-y-6 mb-12">
                     {[
                       'Diseño de patrón exclusivo según tu silueta',
                       'Acceso a muestrarios de sedas de edición limitada',
                       'Dos a tres pruebas de ajuste en nuestro atelier',
                       'Acabados a mano con técnicas de alta costura'
                     ].map((item, idx) => (
                       <li key={idx} className="flex gap-4 items-start">
                         <span className="material-symbols-outlined text-primary">verified</span>
                         <span className="font-bold text-text-main dark:text-gray-200">{item}</span>
                       </li>
                     ))}
                   </ul>
                </div>
              </div>

              <div className="mb-40">
                <div className="text-center mb-24">
                  <h3 className="text-4xl font-display font-bold mb-4">Tu viaje creativo</h3>
                  <div className="w-20 h-1 bg-primary mx-auto rounded-full" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
                  <BespokeStep number="01" icon="calendar_month" title="Cita Previa" desc="Nos conocemos en el atelier para entender tu visión, estilo y necesidades." />
                  <BespokeStep number="02" icon="draw" title="Diseño & Medidas" desc="Esbozamos el concepto y tomamos medidas exactas para un ajuste perfecto." />
                  <BespokeStep number="03" icon="palette" title="Tejidos Nobles" desc="Seleccionamos juntos las texturas, colores y fibras que darán vida a la pieza." />
                  <BespokeStep number="04" icon="auto_fix_high" title="Pruebas & Entrega" desc="Realizamos los ajustes necesarios para que la prenda sea tu segunda piel." />
                </div>
              </div>

              <div className="bg-primary/5 rounded-[4rem] p-16 md:p-24 text-center border border-primary/10 shadow-inner">
                <h3 className="text-4xl font-display font-bold mb-8 italic">"La verdadera elegancia reside en lo que está hecho con calma."</h3>
                <p className="max-w-2xl mx-auto text-lg text-text-secondary dark:text-gray-300 mb-12">
                  ¿Tienes una ocasión especial o buscas esa prenda única que no encuentras en las tiendas? Permíteme asesorarte sin compromiso.
                </p>
                <button onClick={() => setCurrentTab('contacto')} className="bg-primary text-white px-12 py-6 rounded-full font-black uppercase tracking-widest text-xs shadow-xl hover:scale-105 transition-all">Comenzar mi proyecto</button>
              </div>
            </div>
          </div>
        );
      case 'dressitos':
        return (
          <ProductGallery 
            title="Colección Dressitos"
            products={DRESSITOS_PRODUCTS}
            heroData={{
              subtitle: 'La primera caricia para tu bebé en forma de hilos naturales y diseños atemporales.',
              img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuD__u_D8F3yNDJL57dK7n0kdoOf3Nf4FuhtxdoFvdSzgW9wGfA3jT8jG6xxjjaBPvQ2TMKAeU6V60YdrLP8ZPekr8ek_UlNrKAQ8ZZ0oCpeABfGWNOyn4YwAS6pPNPds7Fq8u-e8lbDj__XLIazr3rAG_SnsutBsUDGmf_MnAjhr2yfg9r7v3atS-z5YytfDUK3piQAk5iiAH5yPhr53XZzMhM8PJBayDQpD-uqcquoAj_kp9pTUwfMT_gnPSRlK0eDETsJFM90XFad'
            }}
          />
        );
      case 'fallastyle':
        return (
          <ProductGallery 
            title="Colección Fallastyle"
            products={FALLASTYLE_PRODUCTS}
            showTraditionSection
            heroData={{
              subtitle: 'Tradición valenciana en tus manos. Accesorios únicos hechos a mano con las telas más exclusivas.',
              img: 'https://lh3.googleusercontent.com/aida-public/AB6AXuD3Ftyi010TvuODent0xLMAOEWD9JkkqB2z2qMki9gxMCQ-ZioFijrKx8QqIwJ98EI2MSi0DnLp3Ea5d-o6e_kqymrgNycQ1GQ1_mJJZ2em3ql_vBCRLmITL5fUgYUcAOnrLjbg2BiIbDFSCB_0aobz4zPT9ewNXl3IyURKcyZ7cWGryiKFgiCcj2JpgVgKFCPvMzAcUYET9D9EEBddVHv9NsmIvRzY02XEFHa8gDi9iXl0u-NNh-DtIQXll-W9BzH9iYR2q38MhkEG'
            }}
          />
        );
      case 'arreglos':
        return (
          <div className="min-h-screen bg-background-light dark:bg-background-dark pb-40">
            <div className="relative h-[500px] w-full flex items-center justify-center overflow-hidden mb-20 bg-[#221810]">
              <img src="https://lh3.googleusercontent.com/aida-public/AB6AXuC8vuiH1TN1K0sX5-lf7kw131pSGB4z57OLY4HS1BQyQHotTfNyWloTrdPKl41bHSm40-Y7YjXIKejRL4LkyTsypwXfVrtC_6Xjd6HsVaBzcFLBX43BSU5WB57QywsHNr86lQgN_5-a3K_4ESdmb5QYzOBkDHVj5L8dIxv_mpNEpexY34euBfeWCgXYAlg4j_WflwSYcPROSSouizXjX0m2R4uaTn7lmnthob-CTz9B71Yz-81-J5v4lB-S7AEfIAzydcioK9syI8rS" className="absolute inset-0 w-full h-full object-cover opacity-40 blur-sm" alt="Alterations" />
              <div className="relative z-10 text-center px-6 animate-reveal">
                <span className="inline-block px-4 py-1 mb-6 text-xs font-bold uppercase tracking-[0.3em] text-white bg-primary/80 rounded-full">Servicios Profesionales</span>
                <h1 className="text-5xl md:text-7xl font-display font-black text-white mb-6">Pequeños Arreglos</h1>
                <p className="text-white/80 max-w-2xl mx-auto">Segunda vida a tus prendas favoritas con acabados invisibles.</p>
              </div>
            </div>
            <div className="max-w-[1400px] mx-auto px-6 grid grid-cols-1 md:grid-cols-3 gap-12">
              {ARREGLOS_SERVICES.map(service => (
                <div key={service.id} className="group relative overflow-hidden rounded-[3rem] h-[550px] bg-white shadow-xl hover:shadow-2xl transition-all">
                   <img src={service.image} className="w-full h-full object-cover transition-transform duration-[1.5s] group-hover:scale-110 opacity-80" alt={service.name} />
                   <div className="absolute inset-0 bg-gradient-to-t from-background-dark/90 via-transparent to-transparent" />
                   <div className="absolute top-8 right-8 bg-white/95 backdrop-blur px-6 py-2 rounded-full font-black text-primary text-[10px] tracking-widest uppercase shadow-lg">{service.priceRange}</div>
                   <div className="absolute bottom-10 left-10 right-10 text-white">
                      <div className="flex items-center gap-4 mb-4">
                        <div className="size-14 rounded-2xl bg-primary flex items-center justify-center shadow-lg group-hover:rotate-6 transition-transform"><span className="material-symbols-outlined !text-3xl text-white">{service.icon}</span></div>
                        <h3 className="text-2xl font-bold font-display">{service.name}</h3>
                      </div>
                      <p className="text-sm text-gray-300 leading-relaxed mb-8 opacity-0 group-hover:opacity-100 transition-opacity duration-500">{service.description}</p>
                      <button className="text-[10px] uppercase tracking-widest font-black border-b border-primary pb-1 hover:text-primary transition-colors">Solicitar Presupuesto</button>
                   </div>
                </div>
              ))}
            </div>
          </div>
        );
      case 'sobre-mi':
        return (
          <div className="pt-40 px-6 pb-40 max-w-[1200px] mx-auto">
             <div className="grid grid-cols-1 lg:grid-cols-2 gap-24 items-center">
                <div className="relative">
                   <div className="aspect-[4/5] rounded-[4rem] overflow-hidden shadow-2xl relative z-10 transition-transform duration-700 hover:scale-[1.02]">
                     <img src="https://lh3.googleusercontent.com/aida-public/AB6AXuB72jkOUxY2UxNF1Uo5xCySjaejqD77Uw-0BA2D0uVwXcAkvJtrpj6RGBH1l9zl-ASF6W1uww5C3QXtQLRWByK1NgZagOmpIKsiu-SL8epmB34Wnne_G9RvLf-icby4zXZqJ5euu75gVgo8MZs1734_CfcIZJHbpwpiOa5keFPrXOFBdnkAGBTjlfTAwOuz73Jbh1SF1EnBujl6N0Za-bUaLxn2x5-F3AY86ei0ZC87lsThgjCklYcpG0FcC09Ywk-FjuqDLOs6Tb3m" className="w-full h-full object-cover" alt="Elvira Pérez" />
                   </div>
                </div>
                <div>
                   <span className="text-primary font-black uppercase tracking-[0.4em] text-[10px] mb-6 block">Maestra Costurera</span>
                   <h1 className="text-6xl font-display font-bold mb-8">Elvira Pérez</h1>
                   <div className="space-y-6 text-lg text-text-secondary leading-relaxed">
                     <p>Mi taller es un refugio donde el tiempo se detiene. Aquí, cada cliente es único y cada proyecto recibe toda mi atención y respeto por la materia prima.</p>
                     <p>Formada en la escuela tradicional de sastrería valenciana, combino el rigor de la técnica con la creatividad de los nuevos diseños funcionales.</p>
                     <p className="italic font-display text-primary text-3xl pt-8 leading-snug">"No solo coso prendas, coso recuerdos que perduran en el tiempo."</p>
                   </div>
                </div>
             </div>
          </div>
        );
      case 'contacto':
        return (
          <div className="pt-40 px-6 pb-40 max-w-[1200px] mx-auto">
             <div className="grid grid-cols-1 lg:grid-cols-2 gap-24">
                <div>
                   <h1 className="text-7xl font-display font-bold mb-12">Hablemos</h1>
                   <div className="space-y-12">
                      <div className="flex gap-8 items-center group">
                         <div className="size-16 rounded-3xl bg-primary/10 flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-all duration-500"><span className="material-symbols-outlined !text-3xl">mail</span></div>
                         <div>
                            <p className="text-[10px] uppercase tracking-widest text-text-secondary mb-1">Email Directo</p>
                            <p className="text-2xl font-bold">hola@creativatextil.com</p>
                         </div>
                      </div>
                      <div className="flex gap-8 items-center group">
                         <div className="size-16 rounded-3xl bg-primary/10 flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-all duration-500"><span className="material-symbols-outlined !text-3xl">location_on</span></div>
                         <div>
                            <p className="text-[10px] uppercase tracking-widest text-text-secondary mb-1">Ubicación Atelier</p>
                            <p className="text-2xl font-bold">Valencia, España</p>
                         </div>
                      </div>
                   </div>
                </div>
                <div className="bg-white dark:bg-white/5 p-12 rounded-[3rem] shadow-2xl border border-primary/5">
                   <h3 className="text-2xl font-display font-bold mb-10">Envía un Mensaje</h3>
                   <form className="flex flex-col gap-8" onSubmit={e => { e.preventDefault(); alert('¡Gracias!'); }}>
                      <input className="border-b border-primary/20 focus:border-primary outline-none py-3 bg-transparent text-lg" placeholder="Nombre completo" required />
                      <input className="border-b border-primary/20 focus:border-primary outline-none py-3 bg-transparent text-lg" placeholder="Email" type="email" required />
                      <textarea className="border-b border-primary/20 focus:border-primary outline-none py-3 bg-transparent min-h-[120px] text-lg" placeholder="¿En qué puedo ayudarle?" required />
                      <button type="submit" className="bg-primary text-white py-6 rounded-full font-black uppercase tracking-widest text-xs mt-4 shadow-xl">Enviar al Taller</button>
                   </form>
                </div>
             </div>
          </div>
        );
      default:
        return <Home onNavigate={setCurrentTab} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col transition-colors duration-300">
      <Navbar currentTab={currentTab} onTabChange={setCurrentTab} />
      <main className="flex-grow">{renderContent()}</main>
      <Footer />    

      {ENABLE_AI_ASSISTANT && ( 

      /* Luxury AI Assistant Concierge */
      <div className="fixed bottom-10 right-10 z-[100]">
        {!isAiOpen ? (
          <button onClick={() => setIsAiOpen(true)} className="flex items-center gap-4 bg-primary text-white p-2 pr-10 rounded-full shadow-2xl hover:scale-105 transition-all group">
            <div className="size-14 rounded-full bg-white text-primary flex items-center justify-center shadow-inner"><span className="material-symbols-outlined !text-[32px]">stylus_note</span></div>
            <div className="flex flex-col items-start">
              <span className="text-[9px] uppercase tracking-[0.2em] opacity-80">Asesoría Directa</span>
              <span className="font-bold text-sm tracking-tight">Preguntar a Elvira</span>
            </div>
          </button>
        ) : (
          <div className="bg-white dark:bg-background-dark w-[350px] sm:w-[450px] rounded-[3rem] shadow-2xl border border-primary/10 overflow-hidden flex flex-col animate-reveal">
            <div className="bg-primary p-8 text-white flex items-center justify-between">
              <div className="flex items-center gap-4">
                <span className="material-symbols-outlined !text-[36px]">stylus_note</span>
                <div>
                  <p className="font-display font-bold text-2xl leading-none">Atelier Elvira</p>
                  <p className="text-[10px] uppercase tracking-[0.2em] opacity-80 mt-1">Soporte Artesano</p>
                </div>
              </div>
              <button onClick={() => setIsAiOpen(false)}><span className="material-symbols-outlined !text-3xl text-white">close</span></button>
            </div>
            <div className="p-8 h-[400px] overflow-y-auto flex flex-col gap-6 bg-[#FAF9F6] dark:bg-black/20">
              <div className="bg-white dark:bg-white/5 p-6 rounded-3xl rounded-tl-none shadow-sm text-sm italic font-serif">"¿En qué detalle puedo ayudarle hoy?"</div>
              {aiMessage && <div className="bg-primary text-white p-6 rounded-3xl rounded-tl-none shadow-xl text-sm leading-relaxed">{aiMessage}</div>}
              {isAiLoading && <div className="flex gap-2 p-4 justify-center"><div className="size-2 bg-primary rounded-full animate-bounce" /></div>}
            </div>
            <div className="p-6 bg-white dark:bg-white/5 border-t border-primary/5 flex gap-3 items-center">
              <input value={aiInput} onChange={(e) => setAiInput(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleAiConsult()} placeholder="Escriba aquí..." className="flex-grow bg-[#FAF9F6] dark:bg-white/10 border-none rounded-full px-6 py-4 text-sm focus:ring-1 focus:ring-primary outline-none" />
              <button onClick={handleAiConsult} disabled={isAiLoading} className="bg-primary text-white size-14 rounded-full flex items-center justify-center shadow-lg shrink-0"><span className="material-symbols-outlined !text-3xl">send</span></button>
            </div>
          </div>
        )}
      </div>    )}
    </div>
  );          
};


export default App;
