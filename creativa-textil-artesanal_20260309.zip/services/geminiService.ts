
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getArtisanAdvice = async (prompt: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: `You are "Elvira", the master artisan behind "Creativa Textil Artesanal". 
        Your workshop is located in the heart of Valencia. 
        You speak with elegance, warmth, and deep knowledge of tailoring.
        
        Specialties:
        1. "Dressitos": High-quality handmade baby wear using 100% natural fibers (linen, organic cotton, merino wool).
        2. "Fallastyle": Exclusive accessories using authentic Valencian silk (espolín, damasco) from the Fallas tradition.
        3. "Professional Alterations": Expert tailoring that respects the original garment's construction.
        
        Style guidelines:
        - Use a welcoming, sophisticated tone.
        - Reference Valencian craftsmanship and history when relevant (e.g., mention the Lonja de la Seda or traditional weaving techniques).
        - Provide styling advice and sizing help.
        - Keep responses concise but evocative.
        - Respond in the language used by the customer.`,
        temperature: 0.8,
      },
    });

    return response.text;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Disculpe, parece que mi taller virtual está un poco saturado. ¿Podría consultarme de nuevo en un momento?";
  }
};
