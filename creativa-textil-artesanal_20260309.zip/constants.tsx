
import { Product, Service, Testimonial } from './types';

export const DRESSITOS_PRODUCTS: Product[] = [
  {
    id: 'd1',
    name: 'Ranita de Lino Crudo',
    description: '100% Lino Natural con botones de madera',
    price: 28.00,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCqjlYOYDqWgYhV6xCh2J-i10VUZXIvMfKxVgxwtx9-BUMc9BCSSkRlsBO1MCKP-_XX2VkVzw-rdFHuuHaUSQfglKNT2CkEcXtSJc7T_wSeC8nZeYNHlUyaEjsYpiVEjhDGBmDVTr78rZGxANE7iVeWuZMZ-WMzh4UVwfKnE4QCESZrQiD4shOGmNtE863rcqtR5lEqJ7oXCxfAvFslW9zsiN8qq_jhCtM4_3moRhepLS_Hmu3VzMgIqBD_XyeNbx_VQGYJQmlnBp-c',
    category: 'Recién Nacido',
    tag: 'Popular'
  },
  {
    id: 'd2',
    name: 'Vestido Valenciano Infantil',
    description: 'Bordado a mano en seda suave',
    price: 55.00,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBVDQH8L4bQyRrr0l_1VQt3efvTNNGWxgngsT_QHQwASBPjmLbRUd-SSEVDBt00ncDzVTIxY-L9tQJHiTNJhcgZELjSVEw9atl8y0PJ4CL22_1MVvcyLROOH44w4xJaKUEiS47582cptPmtUtZ3lUqkr2YdPz-Tx1Z0rfLe0-yg1wALB92br0fHKCr7vVyifKbc21pT-TEKSHVRr0Bwwyg98-Y7z0tFLVBIkSXyB0WOVwPnlKpn51fP3ULKaZc_KBP3_ZPWZa_mfAA',
    category: '3-6 Meses',
    tag: 'Nuevo'
  },
  {
    id: 'd3',
    name: 'Conjunto Punto Celeste',
    description: 'Lana Merino de alta calidad',
    price: 34.00,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBKbwDThlHuKqPLSUpA62u1zv3MXECcyowZw3tRkDHfYWqqDrZ8-aFjYo8CPNOP9oOcf-VHvLpCeXjRnjQ4yBeLElRCPOwCAib06O0WY1zezmmfHGKeGqO8Q46XH-uqcigKyszjoqB3updLzAR-9I_3TCgQ8RZsQWQOejYbb2WlwsLeVQ08H4wl-Jcdlj7jBkPTbJtCRk_8olYQwA_DOUoIs3bVr-836gcFEobGDstP9Z1Em_OamYDkp86po4FLbpsXDqDJRKnzC0q8',
    category: '0-3 Meses'
  },
  {
    id: 'd4',
    name: 'Pelele Algodón Orgánico',
    description: 'Estampado floral delicado',
    price: 24.50,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBS-fFgPvpIIfdh2XvdtLbjgcOYStSNbfthMsCqHv84OzCsLdLBKUyBQXhmNH_xCbQgHqGxe8QdEyGINqehFUCwSZ9iaM4_cdr2Q3m0k0KvNEY-l5eJO7LfYLI61Z1Np4hVd8JLqkChz0huovYMx4k7DdSYI1SO2Mypl_9J2cS4iJxjqNUQGjUUMvSKTHUREYda5xbHRgLHP6UkkQHzYn3uUtE6r2Y2y-ANa0m-eOwzwuhAuG_inrCX4z2HKlp-sH-vFwAnFnuB0isC',
    category: '6-12 Meses'
  },
  {
    id: 'd5',
    name: 'Gorro Lana Merino Rosa',
    description: 'Tejido suave anti-alergénico',
    price: 18.00,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAM2CJnuZ_L-8ob7Vxjp06gu9EdLH4OAg9W8zf1zYo8WroCGAmmsqN8FuJ8DkeLzOEc2cge_TeqwLrcn4xico-Rg_TzpNzFwRnQ86M4QVSLfkoD3f3-p47om5baa7h7mmPx77FtGR1fUsgKxPilyYdnBkPNsqtAkoTU25OzfxMAKr6xzTHMmudFodQbVHMYZFvDjxmBd2s16uMeNAa1z8Zp5K7599Ux-oVfkSTza5_ab6VQObtQEtJOF-kbCIR1FYGJWLi233dWYM77',
    category: 'Accesorios'
  },
  {
    id: 'd6',
    name: 'Patucos Artesanos Lazo',
    description: 'Hechos a mano con hilo de algodón',
    price: 15.00,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBfd52WVGwckqmx8ATEPyguigCanaA1OiDXhaiG71k7Bo4SWl3oHZ3nwEGCplG5ied8272jrS5a1XxXi0JsW1gWirrizCXVDTg0V8V-l90aRu1-O5fUmNPP8nmeiBWuqH7NV6g1HkhitRkdmGL706nt_NiozH8C8I_YHIzLVtuDqlQmDAA6PvQz1NuB52qZHDgragtMB5Ui1gOx1pu59PhQDAIwnJsEvEJtIIGlPMvyptxUvrHRJ-kan2Hbfi7ASUXd5P7o03Tac7GD',
    category: 'Accesorios'
  },
  {
    id: 'd7',
    name: 'Manta Arrullo Estrellas',
    description: 'Doble capa de algodón premium',
    price: 32.00,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAc5smbc5ERPaQ3RWFQix3nGIqQen0KyoLgepVW3VoULtCbs9gs2U6SDTpXxw-pnn4u2G-Oyw7icLiSTxHSGmNO-ehHKbgp1torJeGjRzFR00A5mkfg8BirzZnYi_uzx8Qim1aTS08pb7_V3hlLmFsgG0CpBbRtzWz5oyeMib64ltcN6QKiu1pWt1AUVou5iOYrOcu3pMA6qy5Yluqg_7JJJz4GWMpomkUTkIlw1ph7r8rNEB7Wi-KB_8lAQ1mLyKAgLMxTkFFJe1YH',
    category: 'Mantas'
  }
];

export const FALLASTYLE_PRODUCTS: Product[] = [
  {
    id: 'f1',
    name: 'Buff Fallero Floral',
    description: 'Pañuelo tubular elástico con estampado floral inspirado en la seda valenciana. Ideal para el casal.',
    price: 12.00,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDfX8dRCc-AAoFdkg8ZG8iuwqlOr_8XQ2uRLuxC5xzmz9dHh-iqbplFpR68R-O27Q_l-ix9eckhbJ37PXCkGsWY4Sws0kEXIXTaWgef_T6AvIS7EyOf4Gr18umkZZvzrvjxkM1TuAQHTNs_hjpsgJTg8Pn4npojFHvQbtQuDLcMV3_czXDICnkqijYybEL2smIPgSwFgk7tCkfys_tYAcJctp8YjOcv8XVSRSYFcRtuZoNKNURC0Iol7ecFfgNBaOpCDfS-CErBDbhQ',
    category: 'Buffs',
    tag: 'Best Seller'
  },
  {
    id: 'f2',
    name: 'Funda Móvil Premium',
    description: 'Protege tu dispositivo con estilo y tradición. Acolchada y con cierre seguro.',
    price: 15.00,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBqBeaWWsZcaVEyPQvflglrBPdOI7_9hiUIiUsr7gtkEsVwrUJnyeGjYgD4bf7Q5YPpynMTMwTLEFTogb2J3U672nUjuJ4ZPEjHwOCAr3YXC7Hx2pPCW435qibFFWiYV6M9sq7QhVqTxRCAdU-nkaFDQ_R8PUO-hutnvdan3GJSQ2Pnt5jCT69mPdK8KVKrBsH6J8CzwMM2Tm7WALp2u3ODFnXQ5AITBghHYhYyqBcFk_KJ-8h_25RROorz_-hYIW6hrTNBvfmuIYTE',
    category: 'Fundas Móvil'
  },
  {
    id: 'f3',
    name: 'Bolso Tote Artesano',
    description: 'Amplio, resistente y con un diseño exclusivo. Perfecto para llevar tu indumentaria.',
    price: 25.00,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuA3lvYAtvgtQPZQRPyQCElY8-5NVMvGbJq8RxMZHc1l4SDXfKNygvMPg37cm27V1fzHHErZKXWM9OtC6yCq2GaqprWx47SU2Wbh3AdpnyQs6cMbVRDJgiZPhEhwttrLhQwuo1DBpGpt6G8BxNyRqD0YCOkJKQDpUt5EvkIpJT6xlIWsae8lG94I6grLdmQ3SYp-EXvCGjyhB_-Nfe8r9JTUcRudO156HDzeWpbdusRZjkfKbdkz2bPFc760aSH63jQo6eVxAzyLaInW',
    category: 'Bolsos Tote'
  },
  {
    id: 'f4',
    name: 'Llavero Fallero',
    description: 'El detalle perfecto para regalar a tu comisión. Pequeño, elegante y artesanal.',
    price: 8.00,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBzVI7XWd-WOgOlczhPDlT2XkD14MOCuGnEr_3lEO7JOcDX_grGSjrUOzN_Dfu2wALWJU0UEFdBE1iFlAFKZ05qN-4_JiETix8_vsM30XhhzLEPF6C2V2tDPpOgcEVpkS0Ra-0S7RmsLNJFXLJPv_aDy1X_IwBOsrXVkVAooeqAyUj_Hl3chSs9OuaJlwKxTb7eaWTOoervZSjRu5vCU8QMoRP0Yot2gds4UITBO6-GuuAKnrBmBLsW8suD5QCHaPMx33QmV4qekyVm',
    category: 'Llaveros'
  },
  {
    id: 'f5',
    name: 'Monedero Seda',
    description: 'Guarda tus monedas con elegancia. Tela de seda de alta calidad y forro resistente.',
    price: 10.00,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuA0ssV0W8LNNMgS6mZzeYAOwxcN7Eck9tUtd0sDEJ0Q9IkhY7bIzvPx-CnnBVBBoIB7_FNXGsQOMMqYj6qFQVAlYO0ibzYE77xsWitldZYLsjwRpTxnxNs7R94BAiQ0bfTKxuZh9uzKxfIGkvNl95abG1aBbWdN-HeeE80nt5_ngBWmWQbOSgHlPzu9s0CI0SWQGMvu4xPkbG-RI4FKEpA3-Re_V__SyIoil8NnHaOdHx4QVYwF1o0eeTsJFKyTLmMJ6X3Y1Okm5fht',
    category: 'Monederos'
  },
  {
    id: 'f6',
    name: 'Coleteros a Juego',
    description: 'Conjunto de 2 coleteros con telas falleras. El complemento ideal para tu peinado.',
    price: 6.00,
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAnIPRxwZuNlzKayRDFA8zj-YMSQ_GIOFHZf12hTKDzld9QWpA915YasEGuuMwqK979umRQNIUxEYK-jBu1FSO88FY-quDKADHE5BK_0YpykqaHHYpJIb2r_8_f4dVFS-Z5evNkFgN62ltZhKGwVP2mT9O0XR5bH9u5dEOmb2K0u_YWirtBB5qkF-ZaQvfuKF1KE909h7juU2T-Jh7bDOimj_wEWA0FqqUkblQNHrTdfXnAMOsvk3swQai5wuRZCOUxbrvbC-eFEM9j',
    category: 'Accesorios Pelo'
  }
];

export const ARREGLOS_SERVICES: Service[] = [
  {
    id: 's1',
    name: 'Bajos de Ropa',
    description: 'Ajuste de largo para pantalones, faldas y vestidos. Acabados profesionales.',
    priceRange: 'Desde 8€',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuD13esd8XyKTdqL_6TCyu09-NyCOJnaBYNnci25DpC6Bk71aXehkOd0dhsS1uWl7BMJRBOGRA2X2YdH5ARlPDe4V04_-GlNBHCGCKAAhO6orqCdthecZd6oL1Z3EDwrqWv66kRUo2i-PEBEeX-C4bdQPo5GCGisN2Yptej6lxqcZ12SNP0VH3LETEp5QY5jchHjj0etvzIvNYUXQvealx6TS0Ms1JsgAYmyRVgfO9gUINY89wYzZZhpqrqZT6O1OT_LdcoPzHJ-mLXp',
    icon: 'straighten'
  },
  {
    id: 's2',
    name: 'Cojines a Medida',
    description: 'Confección de fundas personalizadas para hogar y jardín.',
    priceRange: 'Desde 15€',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBqv-mciao0jALy2jq_YbCyj38bZxMqFagr-eeDJdkg0-Z1wYNMeX8R7xx8VVxbUX-l_q8twla1MOYeO91nf2lFU2UgkMKBp7LNc-J0jxkRRm47yvSOn3pgnCvAK9DlEi7WkjaqGAhTZKKqBqIassSvtBeEIEJRpX96M_HbPcwWDGR9xEph0F8SumWXXCRP1rYl6MDyKUEvkb0EveF5eDL5eXPGJAM9oWMblFBr49C3DNCLqh5x3B2ogCNClm5RnoXp3jkzKP6stvXU',
    icon: 'chair'
  },
  {
    id: 's3',
    name: 'Cambio de Cremalleras',
    description: 'Sustitución en todo tipo de prendas y complementos.',
    priceRange: 'Desde 12€',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBuMZ7gc99VMu0SsydsW_Dx2ybQMi6-hOZ5JQDfmLLKudWK9B3_Sw6RaVfgtC5UXuYx7Apd3luHz-1L-63WMNRR6Uieqqppf0jpRbwJ8Jd-HSYOraM8WCHhjEi3koyRSlpgvl7DDXqShauX5UorKzZ9FO-ZoLm6RN2zGZB4d77t3ZktjBp_GeuHgsw0CXqGBzagzLsi37_ULDTKgyi18Nyj-zGRDz8sHtqDxlA1aMULv1ja8W8y7GJdYsoaUadjfLIasHb9T4iJqZ_9',
    icon: 'checkroom'
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 't1',
    author: 'Laura M.',
    text: '"La calidad de los tejidos es increíble. Se nota el amor en cada puntada. Mi bebé está guapísimo con su conjunto de Dressitos."',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuD0BYoIu8ICWGmg-wqPfqWIaP_7Xs00RqZOD_c07-byfM8Up6G7ZIGJIfHEuWFUV1K8MGUWgBtkfEJa9rkulhXjn6RIcOq8ZM9swTSMNI5Nx54Tew6O1WL75i3Hdz7NGGY8NIGiP7X7aIg54s5wwC8qByWNNriHCGMPetQ8KwbyCyrlbBNU_l1prVz-SG0jcTvePC1BjEorLpWsEJ92Fowx-q44-D4vuPPlN9ihcBUUfO5MOyLUs23JPp8KqV_UH0FEwd5flg2TzswM',
    rating: 5
  }
];
