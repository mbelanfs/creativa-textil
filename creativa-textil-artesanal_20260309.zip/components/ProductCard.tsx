
import React from 'react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  // Ensure we don't accidentally render the whole product object
  const { name, description, price, image, category, tag } = product;

  return (
    <div className="group flex flex-col bg-white dark:bg-[#2a1f17] rounded-[2rem] overflow-hidden shadow-sm hover:shadow-2xl transition-all duration-500 border border-primary/5">
      {/* Image Container */}
      <div className="relative aspect-[4/5] overflow-hidden bg-gray-100 dark:bg-black/20">
        <img 
          src={image} 
          alt={name}
          className="h-full w-full object-cover transition-transform duration-[1.5s] group-hover:scale-110"
          loading="lazy"
        />
        
        {/* Overlays */}
        {tag && (
          <div className="absolute top-4 left-4 z-10">
            <span className="bg-primary text-white text-[9px] font-black uppercase tracking-[0.2em] px-3 py-1.5 rounded-lg shadow-xl">
              {tag}
            </span>
          </div>
        )}
        
        <div className="absolute inset-0 bg-primary/5 opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none" />
      </div>
      
      {/* Content */}
      <div className="p-6 flex flex-col flex-1">
        <div className="flex justify-between items-start mb-3">
          <h3 className="text-lg font-display font-bold text-text-main dark:text-white line-clamp-1">
            {name}
          </h3>
          <span className="text-lg font-bold text-primary ml-4">
            {price.toFixed(0)}€
          </span>
        </div>
        
        <p className="text-xs text-text-secondary dark:text-gray-400 mb-6 line-clamp-2 leading-relaxed italic">
          "{description}"
        </p>

        <a className="mt-auto text-[10px] font-black uppercase tracking-[0.2em] text-primary hover:text-[#d6651a] flex items-center gap-2 group/link cursor-pointer transition-colors">
          Ver detalles 
          <span className="material-symbols-outlined !text-[14px] transition-transform group-hover/link:translate-x-1">arrow_forward</span>
        </a>
      </div>
    </div>
  );
};

export default ProductCard;
